# Andre Mendoza
# 4/6/25
# P4LAB1b
# Draw my intials using turtle

import turtle
wn = turtle.Screen()
wn.bgcolor("white")
wn.title("Alex")

# Create a turtle named Alex and set its color and size.
alex = turtle.Turtle()
alex.color("red")
alex.pensize(8)

# Draw the intials A M

# Letter A
alex.left(75)
alex.forward(100)
alex.right(150)
alex.forward(100)
alex.backward(50)
alex.right(105)
alex.forward(27)
# Create a gap to the right
alex.penup()
alex.home()
alex.forward(100)
alex.pendown()
# Letter M
alex.left(90)
alex.forward(100)
alex.right(135)
alex.forward(50)
alex.left(90)
alex.forward(50)
alex.right(135)
alex.forward(100)
