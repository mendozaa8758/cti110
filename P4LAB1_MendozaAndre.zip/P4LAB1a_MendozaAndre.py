# Andre Mendoza
# 4/6/25
# P4LAB1a
# Draw a square and triangle using Turtle

# Set up the turtle
import turtle
wn = turtle.Screen()
wn.bgcolor("white")
wn.title("Andre and Amaya")

# Create a turtle for Andre and Amaya
andre = turtle.Turtle()
amaya = turtle.Turtle()

# Create a square using Andre
for _ in range(4):
    andre.forward(100)
    andre.right(90)
# Create a triangle using Amaya
for _ in range(3):
    amaya.forward(100)
    amaya.left(120)
